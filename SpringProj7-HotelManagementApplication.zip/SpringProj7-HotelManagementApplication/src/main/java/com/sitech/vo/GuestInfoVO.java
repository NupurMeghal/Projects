package com.sitech.vo;

public class GuestInfoVO {
	private String gname;
	private String gaddress;
	private String daystoStay;
	private String chargePerDay;
	private String gContact;
	public GuestInfoVO() {
		System.out.println("GuestInfoVO.GuestInfoVO()---0 param const");
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getGaddress() {
		return gaddress;
	}
	public void setGaddress(String gaddress) {
		this.gaddress = gaddress;
	}
	public String getDaystoStay() {
		return daystoStay;
	}
	public void setDaystoStay(String daystoStay) {
		this.daystoStay = daystoStay;
	}
	public String getChargePerDay() {
		return chargePerDay;
	}
	public void setChargePerDay(String chargePerDay) {
		this.chargePerDay = chargePerDay;
	}
	public String getgContact() {
		return gContact;
	}
	public void setgContact(String gContact) {
		this.gContact = gContact;
	}
	
	
	

}
