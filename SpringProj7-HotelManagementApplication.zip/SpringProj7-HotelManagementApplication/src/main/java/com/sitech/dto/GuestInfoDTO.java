package com.sitech.dto;

import java.io.Serializable;

public class GuestInfoDTO  implements Serializable{
	
	private String gname;
	private String gaddress;
	private Integer daystoStay;
	private Float chargePerDay;
	private Long gContact;
	private Float billAmount;
	
	
	public GuestInfoDTO() {
		System.out.println("GuestInfoDTO.GuestInfoDTO()--0 param cons");
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getGaddress() {
		return gaddress;
	}
	public void setGaddress(String gaddress) {
		this.gaddress = gaddress;
	}
	public Integer getDaystoStay() {
		return daystoStay;
	}
	public void setDaystoStay(Integer daystoStay) {
		this.daystoStay = daystoStay;
	}
	public Float getChargePerDay() {
		return chargePerDay;
	}
	public void setChargePerDay(Float chargePerDay) {
		this.chargePerDay = chargePerDay;
	}
	public Long getgContact() {
		return gContact;
	}
	public void setgContact(Long gContact) {
		this.gContact = gContact;
	}
	public Float getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(Float billAmount) {
		this.billAmount = billAmount;
	}
	
	
	

}
