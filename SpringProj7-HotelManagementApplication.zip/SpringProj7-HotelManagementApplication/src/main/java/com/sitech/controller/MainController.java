package com.sitech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sitech.dto.GuestInfoDTO;
import com.sitech.service.IGuestService;
import com.sitech.vo.GuestInfoVO;

@Component("gcontroller")
public class MainController {
	@Autowired
	//HAS-A property
	IGuestService service;
	public MainController() {
		System.out.println("MainController.MainController()--0 param cons");
	}
	public String processGuest(GuestInfoVO vo)throws Exception{
		//convert vo object data to dto obj data
		GuestInfoDTO dto=new GuestInfoDTO();
		dto.setGname(vo.getGname());
		dto.setGaddress(vo.getGaddress());
		dto.setDaystoStay(Integer.parseInt(vo.getDaystoStay()));
		dto.setChargePerDay(Float.parseFloat(vo.getChargePerDay()));
		//use service obj call registraionGuest() method
		String result=service.registerGuest(dto);
		return result;
		
		
	}
	

}
