package com.sitech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sitech.bo.GuestInfoBO;
@Component("gdao")

public class GuestDAOImpl implements IGuestDAO {
	private static final String query="Insert into guestInfo values(?,?,?)";

	//HAs-A property
	@Autowired
	DataSource ds;
	public GuestDAOImpl() {
		System.out.println("GuestDAOImpl.GuestDAOImpl()---0 param const");
	}
	

	@Override
	public int insert(GuestInfoBO bo) throws Exception{
		int count=0;
		//get pooled jdbc con object
		try(Connection con=ds.getConnection();
				PreparedStatement ps=con.prepareStatement(query)){
			if(ps!=null) {
				//set values to query from bo class object
				ps.setString(1, bo.getGname());
				ps.setString(2, bo.getGaddress());
				ps.setDouble(3, bo.getBillAmount());
				//execute the query
				count=ps.executeUpdate();
				
			}
		}
		catch(SQLException se) {
			se.printStackTrace();
			throw se;
		}
		catch(Exception e) {
		e.printStackTrace();
		throw e;
		}
		return count;

}
}
