package com.sitech.test;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sitech.controller.MainController;
import com.sitech.vo.GuestInfoVO;

public class LayredApplicationTest {
	public static void main(String[] args) {
		       String gname=null,gaddress=null,gcontact=null,daystoStay=null,chargePerDay=null;
				
		
		//collect input form user
		Scanner sc=new Scanner(System.in);
		if(sc!=null) {
			System.out.println("Enter Guest name");
			gname=sc.next();
			
			System.out.println("Enter Guest address");
			gaddress=sc.next();
			
			System.out.println("Enter Guest contact");
			gcontact=sc.next();
			
			System.out.println("Enter no of days to stay");
			daystoStay=sc.next();
			
			System.out.println("Enter charge per day");
			chargePerDay=sc.next();
			}
		//create VO class object
		GuestInfoVO vo = new GuestInfoVO();
		//set the local variables data to vo object
		vo.setGname(gname);
		vo.setGaddress(gaddress);
		vo.setgContact(gcontact);
		vo.setDaystoStay(daystoStay);
		vo.setChargePerDay(chargePerDay);
		
		//  create IOC container
		ClassPathXmlApplicationContext ctx= new ClassPathXmlApplicationContext("com/sitech/cfg/applicationContext.xml");
		//get target bean class object/controller
		MainController controller=ctx.getBean("gcontroller",MainController.class);
		try {
			//call b.method
			String msg=controller.processGuest(vo);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
