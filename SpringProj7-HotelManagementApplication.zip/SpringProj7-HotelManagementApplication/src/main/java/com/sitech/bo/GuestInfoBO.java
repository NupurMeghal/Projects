package com.sitech.bo;

public class GuestInfoBO {
	private String gname;
	private String gaddress;
	private Long gContact;
	private Float billAmount;
	public GuestInfoBO() {
		System.out.println("GuestInfoBO.GuestInfoBO()--0 param cons");
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getGaddress() {
		return gaddress;
	}
	public void setGaddress(String gaddress) {
		this.gaddress = gaddress;
	}
	public Long getgContact() {
		return gContact;
	}
	public void setgContact(Long gContact) {
		this.gContact = gContact;
	}
	public Float getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(Float billAmount) {
		this.billAmount = billAmount;
	}
	
	
	
	
	
}
