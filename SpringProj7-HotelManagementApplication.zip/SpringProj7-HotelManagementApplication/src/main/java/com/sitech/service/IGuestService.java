package com.sitech.service;

import com.sitech.dao.IGuestDAO;
import com.sitech.dto.GuestInfoDTO;

public interface IGuestService {
    public String registerGuest(GuestInfoDTO dto) throws Exception;
   }
