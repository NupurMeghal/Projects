package com.sitech.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sitech.bo.GuestInfoBO;
import com.sitech.dao.IGuestDAO;
import com.sitech.dto.GuestInfoDTO;
@Component("gservice")

public class GuestServiceImpl implements IGuestService {
	@Autowired
	IGuestDAO dao;
	public GuestServiceImpl() {
		System.out.println("GuestServiceImpl.GuestServiceImpl()--0 param cons");
	}
	public String registerGuest(GuestInfoDTO dto)throws Exception{
		System.out.println("GuestServiceImpl.registerGuest()---0  param cons");
		//calculate bill amount
		float billAmount=dto.getDaystoStay()*dto.getChargePerDay();
		//prepare bo object having to be stored to db table
		GuestInfoBO  bo=new GuestInfoBO();
		bo.setGname(dto.getGname());
		bo.setGaddress(dto.getGaddress());
		bo.setBillAmount(billAmount);
		//use dao object to call insert() method
int count=dao.insert(bo);
if(count==0) {
	return "Registration failed---";
}
else {
	return "Registration Success!";
}
	
	

}
}
